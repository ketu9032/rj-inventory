module.exports = {
  url: 'mongodb+srv://home-inventory:home-inventory@cluster0.0mt53.mongodb.net/home-inventory?retryWrites=true&w=majority',
  jsonWebToken: {
    privateKey: 'home!inventory'
  }
};
